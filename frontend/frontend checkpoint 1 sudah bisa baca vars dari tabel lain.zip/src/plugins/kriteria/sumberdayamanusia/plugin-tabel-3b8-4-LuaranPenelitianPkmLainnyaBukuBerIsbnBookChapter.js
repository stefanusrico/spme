import { BasePlugin } from "../../core/BasePlugin.js"
import { PluginUtils } from "../../utils/PluginUtils.js"
import { fetchScoreDetails } from "../../../utils/fetchScoreDetail.js"

export class LuaranPenelitianPkmLainnyaBukuBerIsbnPlugin extends BasePlugin {
  constructor() {
    super({
      code: "3b8-4",
      name: "Luaran Penelitian/PkM Lainnya - Buku ber-ISBN, Book Chapter",
      description:
        "Plugin for processing Luaran Penelitian/PkM Lainnya - Buku ber-ISBN, Book Chapter",
    })
  }

  configureSection(config) {
    return {
      ...config,
      isLuaranPenelitianBuku: true,
    }
  }

  hasDefaultData() {
    return false
  }

  // ✅ Use dynamic base processing dengan konversi tanggal awal
  async processExcelData(workbook, tableCode, config, prodiName, sectionCode) {
    const result = await super.processExcelData(
      workbook,
      tableCode,
      config,
      prodiName,
      sectionCode
    )

    // Segera konversi tanggal ke format yang benar setelah data diproses
    if (result && result.allRows) {
      result.allRows = result.allRows.map((item) => {
        const fieldMap = this.mapLuaranBukuFields(item)
        if (
          fieldMap.tanggal &&
          item[fieldMap.tanggal] &&
          typeof item[fieldMap.tanggal] === "number"
        ) {
          item[fieldMap.tanggal] = PluginUtils.excelSerialDateToFormat(
            item[fieldMap.tanggal]
          )
        }
        return item
      })
    }

    return result
  }

  // ✅ Dynamic field mapping - pastikan bisa mengenali field dari DB
  mapLuaranBukuFields(sampleItem) {
    return {
      luaran_penelitian: this.findFieldByPattern(sampleItem, [
        "luaran_penelitian_dan_pkm",
        "luaran_penelitian",
        "luaran",
        "penelitian",
        "pkm",
      ]),
      tanggal: this.findFieldByPattern(sampleItem, [
        "tanggal_hh_bb_tttt",
        "tanggal",
        "hh_bb_tttt",
        "date",
      ]),
      isbn: this.findFieldByPattern(sampleItem, [
        "keterangan_isbn",
        "isbn",
        "keterangan",
        "nomor",
      ]),
    }
  }

  async calculateScore(data, config, additionalData = {}) {
    let ND = 0

    const fieldMap = this.mapLuaranBukuFields(data[0] || {})

    const isValidField = (value) => {
      if (typeof value === "string") {
        return value.trim() !== ""
      }
      if (typeof value === "number") {
        return !isNaN(value)
      }
      return false
    }

    // ✅ Dynamic field validation
    data.forEach((item) => {
      if (
        isValidField(item[fieldMap.luaran_penelitian]) &&
        isValidField(item[fieldMap.tanggal]) &&
        isValidField(item[fieldMap.isbn])
      ) {
        ND += 1
      }
    })

    // Fetch score details from other tables
    const [
      responseScoreDetail,
      responseScoreDetail1,
      responseScoreDetail2,
      responseScoreDetail3,
    ] = await Promise.all([
      fetchScoreDetails("3a1", additionalData.projectId),
      fetchScoreDetails("3b8-1", additionalData.projectId),
      fetchScoreDetails("3b8-2", additionalData.projectId),
      fetchScoreDetails("3b8-3", additionalData.projectId),
    ])

    if (
      !responseScoreDetail ||
      !responseScoreDetail1 ||
      !responseScoreDetail2 ||
      !responseScoreDetail3
    ) {
      console.warn("Masukan data dari tabel 3a1, 3b8-1, 3b8-2, dan 3b8-3")
      return {
        scores: [{ butir: 31, nilai: 0 }],
        scoreDetail: {},
      }
    }

    const NDTPS = Number(responseScoreDetail?.NDTPS || 0)
    const NA = Number(responseScoreDetail1?.NA || 0)
    const NB = Number(responseScoreDetail2?.NB || 0)
    const NC = Number(responseScoreDetail3?.NC || 0)

    // Calculate RLP
    const RLP =
      NDTPS > 0
        ? Math.round(((2 * (NA + NB + NC) + ND) / NDTPS) * 100) / 100
        : 0

    let score = 0
    if (RLP >= 1) {
      score = 4
    } else {
      score = 2 + 2 * RLP
    }

    return {
      scores: [{ butir: 31, nilai: score }],
      scoreDetail: { NA, NB, NC, ND, RLP },
    }
  }

  // ✅ Dynamic normalization dengan konversi tanggal
  normalizeData(data) {
    return data.map((item) => {
      const result = { ...item }
      const fieldMap = this.mapLuaranBukuFields(result)

      Object.entries(fieldMap).forEach(([key, fieldName]) => {
        if (fieldName && result[fieldName] !== undefined) {
          if (key === "tanggal") {
            const dateValue = result[fieldName]

            // Format ISO dari database: "2021-07-27" -> "27/07/2021"
            if (
              typeof dateValue === "string" &&
              /^\d{4}-\d{2}-\d{2}$/.test(dateValue)
            ) {
              const [year, month, day] = dateValue.split("-")
              result[fieldName] = `${day}/${month}/${year}`
            }
            // Nilai Excel serial number
            else if (typeof dateValue === "number") {
              const jsDate = new Date((dateValue - 25569) * 86400 * 1000)
              if (!isNaN(jsDate.getTime())) {
                const day = String(jsDate.getDate()).padStart(2, "0")
                const month = String(jsDate.getMonth() + 1).padStart(2, "0")
                const year = jsDate.getFullYear()
                result[fieldName] = `${day}/${month}/${year}`
              }
            }
          } else {
            result[fieldName] = PluginUtils.normalizeTextField(
              result[fieldName]
            )
          }
        }
      })
      return result
    })
  }

  // ✅ Dynamic validation
  validateData(data) {
    const errors = []

    data.forEach((item, index) => {
      const fieldMap = this.mapLuaranBukuFields(item)

      const requiredFields = [
        {
          field: fieldMap.luaran_penelitian,
          name: "Luaran Penelitian dan PkM",
        },
        { field: fieldMap.tanggal, name: "Tanggal (HH/BB/TTTT)" },
        { field: fieldMap.isbn, name: "Keterangan (Nomor ISBN)" },
      ]

      requiredFields.forEach(({ field, name }) => {
        if (field && !item[field]) {
          errors.push(`Row ${index + 1}: ${name} harus diisi`)
        }
      })
    })

    return {
      valid: errors.length === 0,
      errors,
    }
  }

  // ✅ Helper method
  findFieldByPattern(item, patterns) {
    const fields = Object.keys(item)

    for (const pattern of patterns) {
      const field = fields.find((f) =>
        f.toLowerCase().includes(pattern.toLowerCase())
      )
      if (field) return field
    }

    return null
  }
}

export const luaranPenelitianPkmLainnyaBukuBerIsbnPlugin =
  new LuaranPenelitianPkmLainnyaBukuBerIsbnPlugin()
export default luaranPenelitianPkmLainnyaBukuBerIsbnPlugin
