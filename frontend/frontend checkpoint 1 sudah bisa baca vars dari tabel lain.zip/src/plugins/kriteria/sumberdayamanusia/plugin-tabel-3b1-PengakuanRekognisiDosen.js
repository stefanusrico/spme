import { BasePlugin } from "../../core/BasePlugin.js"
import { PluginUtils } from "../../utils/PluginUtils.js"
import { fetchScoreDetails } from "../../../utils/fetchScoreDetail.js"

export class PengakuanRekognisiDtpsPlugin extends BasePlugin {
  constructor() {
    super({
      code: "3b1",
      name: "Pengakuan/Rekognisi DTPS",
      description: "Plugin for processing rekognisi",
    })
  }

  configureSection(config) {
    return {
      ...config,
      isPengakuanRekognisiDtps: true,
    }
  }

  hasDefaultData() {
    return false
  }

  // ✅ Use dynamic base processing
  async processExcelData(workbook, tableCode, config, prodiName, sectionCode) {
    return super.processExcelData(
      workbook,
      tableCode,
      config,
      prodiName,
      sectionCode
    )
  }

  // ✅ Override field type detection
  detectFieldType(fieldName, value) {
    const fieldLower = fieldName.toLowerCase()

    if (
      fieldLower.includes("tingkat_wilayah") ||
      fieldLower.includes("tingkat_nasional") ||
      fieldLower.includes("tingkat_internasional")
    ) {
      return "boolean"
    }

    // Year field
    if (fieldLower.includes("tahun")) {
      return "text"
    }

    return super.detectFieldType(fieldName, value)
  }

  // ✅ Dynamic field mapping
  mapRekognisiFields(sampleItem) {
    return {
      nama_dosen: this.findFieldByPattern(sampleItem, ["nama_dosen", "nama"]),
      bidang_keahlian: this.findFieldByPattern(sampleItem, [
        "bidang_keahlian",
        "keahlian",
        "bidang",
      ]),
      rekognisi: this.findFieldByPattern(sampleItem, [
        "rekognisi",
        "pengakuan",
      ]),
      bukti_pendukung: this.findFieldByPattern(sampleItem, [
        "bukti_pendukung",
        "bukti",
      ]),
      tingkat_wilayah: this.findFieldByPattern(sampleItem, [
        "tingkat_wilayah",
        "wilayah",
      ]),
      tingkat_nasional: this.findFieldByPattern(sampleItem, [
        "tingkat_nasional",
        "nasional",
      ]),
      tingkat_internasional: this.findFieldByPattern(sampleItem, [
        "tingkat_internasional",
        "internasional",
      ]),
      tahun: this.findFieldByPattern(sampleItem, ["tahun", "year"]),
    }
  }

  // ✅ Override field processing for boolean fields
  processFieldValue(fieldName, value, fieldType = "auto") {
    if (fieldType === "auto") {
      fieldType = this.detectFieldType(fieldName, value)
    }

    if (fieldType === "boolean") {
      const stringValue = String(value || "")
        .trim()
        .toLowerCase()
      return (
        stringValue === "v" ||
        stringValue === "✓" ||
        stringValue === "true" ||
        value === true ||
        value === 1
      )
    }

    return super.processFieldValue(fieldName, value, fieldType)
  }

  async calculateScore(data, config, additionalData = {}) {
    let NRD = 0

    // ✅ Dynamic field access for counting valid rekognisi
    data.forEach((item) => {
      const fieldMap = this.mapRekognisiFields(item)

      if (
        item[fieldMap.nama_dosen]?.trim() &&
        item[fieldMap.rekognisi]?.trim() &&
        this.hasValidRekognisi(item, fieldMap)
      ) {
        NRD++
      }
    })

    const response = await fetchScoreDetails("3a1", additionalData.projectId)
    if (!response) {
      return {
        scores: [{ butir: 25, nilai: 0 }],
        scoreDetail: { RRD: 0, NRD: 0, NDTPS: 0 },
      }
    }

    const NDTPS = response?.NDTPS || 0

    if (NDTPS === 0) {
      return {
        scores: [{ butir: 25, nilai: 0 }],
        scoreDetail: { RRD: 0, NRD, NDTPS: 0 },
      }
    }

    const RRD = Math.round((NRD / NDTPS) * 10000) / 10000

    let score = 0

    if (RRD >= 0.5) {
      score = 4
    } else {
      score = 2 + 4 * RRD
    }

    if (score < 2) score = 2
    if (score > 4) score = 4

    score = Math.round(score * 100) / 100

    return {
      scores: [{ butir: 25, nilai: score }],
      scoreDetail: {
        RRD: Math.round(RRD * 10000) / 10000,
        NRD,
        NDTPS,
      },
    }
  }

  // ✅ Dynamic validation for rekognisi type
  hasValidRekognisi(item, fieldMap) {
    const hasValidTingkatWilayah = this.checkBooleanField(
      item[fieldMap.tingkat_wilayah]
    )
    const hasValidTingkatNasional = this.checkBooleanField(
      item[fieldMap.tingkat_nasional]
    )
    const hasValidTingkatInternasional = this.checkBooleanField(
      item[fieldMap.tingkat_internasional]
    )

    return (
      hasValidTingkatWilayah ||
      hasValidTingkatNasional ||
      hasValidTingkatInternasional
    )
  }

  // ✅ Helper method for checking boolean fields
  checkBooleanField(value) {
    const stringValue = String(value || "")
      .trim()
      .toLowerCase()
    return (
      stringValue === "v" ||
      stringValue === "✓" ||
      stringValue === "x" ||
      stringValue === "true" ||
      value === true ||
      value === 1
    )
  }

  // ✅ Dynamic validation
  validateData(data) {
    const errors = []

    data.forEach((item, index) => {
      const fieldMap = this.mapRekognisiFields(item)

      // Check required fields
      const requiredFields = [
        { field: fieldMap.nama_dosen, name: "Nama dosen" },
        { field: fieldMap.bidang_keahlian, name: "Bidang keahlian" },
        { field: fieldMap.rekognisi, name: "Rekognisi" },
        { field: fieldMap.bukti_pendukung, name: "Bukti pendukung" },
        { field: fieldMap.tahun, name: "Tahun" },
      ]

      requiredFields.forEach(({ field, name }) => {
        if (field && !item[field]?.trim()) {
          errors.push(`Row ${index + 1}: ${name} harus diisi`)
        }
      })

      // Validate rekognisi type and level
      if (
        item[fieldMap.nama_dosen]?.trim() &&
        item[fieldMap.rekognisi]?.trim()
      ) {
        if (!this.hasValidRekognisi(item, fieldMap)) {
          errors.push(
            `Row ${
              index + 1
            }: Rekognisi tidak sesuai dengan kriteria yang ditetapkan atau tingkat tidak valid`
          )
        }
      }

      // Validate year format
      if (fieldMap.tahun) {
        const year = item[fieldMap.tahun]?.trim()
        if (year && !/^\d{4}$/.test(year)) {
          errors.push(`Row ${index + 1}: Format tahun harus YYYY (4 digit)`)
        }

        // Validate year range (last 3 years)
        if (year && /^\d{4}$/.test(year)) {
          const currentYear = new Date().getFullYear()
          const yearValue = parseInt(year)
          if (yearValue < currentYear - 2 || yearValue > currentYear) {
            errors.push(
              `Row ${index + 1}: Tahun harus dalam rentang 3 tahun terakhir (${
                currentYear - 2
              } - ${currentYear})`
            )
          }
        }
      }
    })

    return {
      valid: errors.length === 0,
      errors,
    }
  }

  // ✅ Dynamic normalization
  normalizeData(data) {
    return data.map((item) => {
      const result = { ...item }
      const fieldMap = this.mapRekognisiFields(result)

      Object.entries(fieldMap).forEach(([key, fieldName]) => {
        if (fieldName && result[fieldName] !== undefined) {
          const fieldType = this.detectFieldType(fieldName, result[fieldName])
          result[fieldName] = this.processFieldValue(
            fieldName,
            result[fieldName],
            fieldType
          )
        }
      })

      return result
    })
  }

  // ✅ Helper method
  findFieldByPattern(item, patterns) {
    const fields = Object.keys(item)

    for (const pattern of patterns) {
      const field = fields.find((f) =>
        f.toLowerCase().includes(pattern.toLowerCase())
      )
      if (field) return field
    }

    return null
  }
}

export const pengakuanRekognisiDtpsPlugin = new PengakuanRekognisiDtpsPlugin()
export default pengakuanRekognisiDtpsPlugin
