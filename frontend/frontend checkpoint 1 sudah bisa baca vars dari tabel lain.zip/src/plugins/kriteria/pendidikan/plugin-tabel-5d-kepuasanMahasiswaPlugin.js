import { BasePlugin } from "../../core/BasePlugin.js"
import { PluginUtils } from "../../utils/PluginUtils.js"

export class KepuasanMahasiswaPlugin extends BasePlugin {
  constructor() {
    super({
      code: "5d",
      name: "Kepuasan Mahasiswa Plugin",
      description: "Plugin for student satisfaction data processing",
    })
  }

  configureSection(config) {
    return {
      ...config,
      isKepuasanMahasiswaSection: true,
    }
  }

  hasDefaultData() {
    return false
  }

  // ✅ Use dynamic base processing
  async processExcelData(workbook, tableCode, config, prodiName, sectionCode) {
    const result = await super.processExcelData(
      workbook,
      tableCode,
      config,
      prodiName,
      sectionCode
    )

    // Konversi nilai persentase dari Excel jika ada
    if (result && result.allRows) {
      result.allRows = result.allRows.map((item) => {
        const fieldMap = this.mapKepuasanFields(item)

        // Konversi semua field tingkat kepuasan ke persentase
        const percentageFields = [
          fieldMap.tingkat_sangat_baik,
          fieldMap.tingkat_baik,
          fieldMap.tingkat_cukup,
          fieldMap.tingkat_kurang,
        ]

        percentageFields.forEach((field) => {
          if (field && item[field] !== undefined) {
            const rawPercentage = this.convertToPercentage(item[field])
            // ✅ Format ke 2 digit desimal menggunakan PluginUtils
            item[field] = PluginUtils.formatNumber(rawPercentage, 2)
          }
        })

        return item
      })
    }

    return result
  }

  // ✅ Helper untuk konversi ke persentase dengan 2 digit desimal
  convertToPercentage(value) {
    if (value === null || value === undefined || value === "") {
      return 0
    }

    let result = 0

    // Jika sudah berupa number
    if (typeof value === "number") {
      // Jika nilai > 1 tapi <= 100, asumsikan sudah persentase
      if (value > 1 && value <= 100) {
        result = value
      }
      // Jika nilai <= 1, asumsikan proporsi (konversi ke persentase)
      else if (value >= 0 && value <= 1) {
        result = value * 100
      } else {
        result = value
      }
    }
    // Konversi string ke number
    else if (typeof value === "string") {
      // Hapus karakter % jika ada
      const cleanValue = value.replace(/\s*%\s*$/, "")

      const numValue = parseFloat(cleanValue)
      if (isNaN(numValue)) {
        return 0
      }

      // Jika ada simbol % di string asal, nilai sudah persentase
      if (value.includes("%")) {
        result = numValue
      }
      // Jika nilai > 1 tapi <= 100, asumsikan sudah persentase
      else if (numValue > 1 && numValue <= 100) {
        result = numValue
      }
      // Jika nilai <= 1, asumsikan proporsi (konversi ke persentase)
      else if (numValue >= 0 && numValue <= 1) {
        result = numValue * 100
      } else {
        result = numValue
      }
    }

    // ✅ Format hasil ke 2 digit desimal
    return parseFloat(PluginUtils.formatNumber(result, 2))
  }

  // ✅ Override field type detection
  detectFieldType(fieldName, value) {
    const fieldLower = fieldName.toLowerCase()

    // Numeric fields for satisfaction levels
    if (
      fieldLower.includes("tingkat_sangat_baik") ||
      fieldLower.includes("tingkat_baik") ||
      fieldLower.includes("tingkat_cukup") ||
      fieldLower.includes("tingkat_kurang") ||
      fieldLower.includes("sangat_baik") ||
      fieldLower.includes("baik") ||
      fieldLower.includes("cukup") ||
      fieldLower.includes("kurang")
    ) {
      return "percentage" // Custom type untuk persentase
    }

    return super.detectFieldType(fieldName, value)
  }

  // ✅ Process field value berdasarkan type
  processFieldValue(fieldName, value, fieldType = "auto") {
    if (fieldType === "auto") {
      fieldType = this.detectFieldType(fieldName, value)
    }

    if (fieldType === "percentage") {
      const rawPercentage = this.convertToPercentage(value)
      // ✅ Format ke 2 digit desimal
      return PluginUtils.formatNumber(rawPercentage, 2)
    }

    return super.processFieldValue(fieldName, value, fieldType)
  }

  // ✅ Dynamic field mapping
  mapKepuasanFields(sampleItem) {
    return {
      aspek_yang_diukur: this.findFieldByPattern(sampleItem, [
        "aspek_yang_diukur",
        "aspek",
        "diukur",
      ]),
      tingkat_sangat_baik: this.findFieldByPattern(sampleItem, [
        "tingkat_sangat_baik",
        "sangat_baik",
        "sangat baik",
      ]),
      tingkat_baik:
        this.findFieldByPattern(sampleItem, ["tingkat_baik", "baik"]) &&
        !this.findFieldByPattern(sampleItem, ["sangat_baik"]),
      tingkat_cukup: this.findFieldByPattern(sampleItem, [
        "tingkat_cukup",
        "cukup",
      ]),
      tingkat_kurang: this.findFieldByPattern(sampleItem, [
        "tingkat_kurang",
        "kurang",
      ]),
      rencana_tindak_lanjut: this.findFieldByPattern(sampleItem, [
        "rencana_tindak_lanjut",
        "rencana",
        "tindak_lanjut",
        "upps_ps",
      ]),
    }
  }

  async calculateScore(data, config, additionalData = {}) {
    const allRows = Array.isArray(data) ? data : data?.allRows || []

    if (!allRows || allRows.length === 0) {
      console.warn("Kepuasan Mahasiswa: Tidak ada data untuk dihitung skornya.")
      return {
        scores: [{ butir: 52, nilai: 0 }],
        scoreDetail: {
          TKMi: [],
          TKM: 0,
        },
      }
    }

    const fieldMap = this.mapKepuasanFields(allRows[0] || {})
    const TKMiValues = []
    let totalNilaiTKM_i = 0
    const JUMLAH_ASPEK_SEHARUSNYA = 5

    // ✅ Dynamic field access for calculations - sekarang bekerja dengan persentase
    allRows.forEach((item) => {
      // Parse nilai menjadi number untuk perhitungan
      let sangatBaik = parseFloat(item[fieldMap.tingkat_sangat_baik] || 0)
      let baik = parseFloat(item[fieldMap.tingkat_baik] || 0)
      let cukup = parseFloat(item[fieldMap.tingkat_cukup] || 0)
      let kurang = parseFloat(item[fieldMap.tingkat_kurang] || 0)

      // Konversi dari persen ke proporsi (0-1) untuk perhitungan
      let ai = sangatBaik / 100
      let bi = baik / 100
      let ci = cukup / 100
      let di = kurang / 100

      // Cek total proporsi, idealnya 1.0 (100%)
      const totalProporsi = ai + bi + ci + di

      // Normalisasi jika total tidak sama dengan 1.0
      if (totalProporsi > 0 && Math.abs(totalProporsi - 1.0) > 0.01) {
        ai = ai / totalProporsi
        bi = bi / totalProporsi
        ci = ci / totalProporsi
        di = di / totalProporsi

        console.log(
          `Normalized percentages for row: Total was ${PluginUtils.formatNumber(
            totalProporsi * 100,
            2
          )}%`
        )
      }

      let TKMi = 0

      if (totalProporsi > 0) {
        // Rumus TKM: (4*persentase sangat baik + 3*persentase baik + 2*persentase cukup + 1*persentase kurang)
        TKMi = parseFloat((4 * ai + 3 * bi + 2 * ci + 1 * di).toFixed(3))
        totalNilaiTKM_i += TKMi
        // ✅ Format nilai TKMi ke 2 digit desimal
        TKMiValues.push(parseFloat(PluginUtils.formatNumber(TKMi, 2)))
      } else {
        TKMiValues.push(0)
      }
    })

    const TKM_avg_skala_1_4 = totalNilaiTKM_i / JUMLAH_ASPEK_SEHARUSNYA
    const TKM_persen_final =
      TKM_avg_skala_1_4 > 0 ? ((TKM_avg_skala_1_4 - 1) / 3) * 100 : 0
    const skorAkhir =
      TKM_persen_final >= 75
        ? 4
        : TKM_persen_final >= 25
        ? 8 * (TKM_persen_final / 100) - 2
        : 0

    return {
      scores: [
        {
          butir: 52,
          // ✅ Format nilai akhir ke 2 digit desimal
          nilai: parseFloat(
            PluginUtils.formatNumber(Math.max(0, Math.min(4, skorAkhir)), 2)
          ),
        },
      ],
      scoreDetail: {
        TKMi: TKMiValues,
        // ✅ Format nilai TKM ke 2 digit desimal
        TKM: parseFloat(PluginUtils.formatNumber(TKM_persen_final, 2)),
        details: [
          {
            no: 52,
            sub: "A",
            // ✅ Format nilai detail ke 2 digit desimal
            nilai: parseFloat(PluginUtils.formatNumber(skorAkhir, 2)),
          },
        ],
      },
    }
  }

  // ✅ Dynamic normalization - sekarang menangani persentase dan memformatnya
  normalizeData(data) {
    return data.map((item) => {
      const result = { ...item }
      const fieldMap = this.mapKepuasanFields(result)

      Object.entries(fieldMap).forEach(([key, fieldName]) => {
        if (fieldName && result[fieldName] !== undefined) {
          const fieldType = this.detectFieldType(fieldName, result[fieldName])
          result[fieldName] = this.processFieldValue(
            fieldName,
            result[fieldName],
            fieldType
          )
        }
      })

      return result
    })
  }

  // ✅ Dynamic validation - update untuk memvalidasi persentase
  validateData(data) {
    const errors = []

    if (!Array.isArray(data)) {
      errors.push("Data utama harus berupa array.")
      return { valid: false, errors }
    }

    data.forEach((item, index) => {
      const fieldMap = this.mapKepuasanFields(item)

      if (
        fieldMap.aspek_yang_diukur &&
        (!item[fieldMap.aspek_yang_diukur] ||
          String(item[fieldMap.aspek_yang_diukur]).trim() === "")
      ) {
        errors.push(`Baris ${index + 1}: 'aspek_yang_diukur' harus diisi.`)
      }

      // Validasi field persentase
      const percentageFields = [
        { field: fieldMap.tingkat_sangat_baik, name: "Tingkat Sangat Baik" },
        { field: fieldMap.tingkat_baik, name: "Tingkat Baik" },
        { field: fieldMap.tingkat_cukup, name: "Tingkat Cukup" },
        { field: fieldMap.tingkat_kurang, name: "Tingkat Kurang" },
      ].filter((x) => x.field)

      percentageFields.forEach(({ field, name }) => {
        const val = parseFloat(item[field] || 0)
        if (val < 0 || val > 100) {
          errors.push(
            `Baris ${
              index + 1
            }: '${name}' harus berupa persentase antara 0-100%. Ditemukan: ${val}%`
          )
        }
      })

      // Validasi total persentase mendekati 100%
      const totalPersen = percentageFields.reduce((sum, { field }) => {
        return sum + parseFloat(item[field] || 0)
      }, 0)

      if (totalPersen > 0 && Math.abs(totalPersen - 100) > 5) {
        errors.push(
          `Baris ${
            index + 1
          }: Total persentase tingkat kepuasan seharusnya 100%. Ditemukan: ${PluginUtils.formatNumber(
            totalPersen,
            2
          )}%`
        )
      }
    })

    return {
      valid: errors.length === 0,
      errors,
    }
  }

  // ✅ Helper method
  findFieldByPattern(item, patterns) {
    const fields = Object.keys(item)

    for (const pattern of patterns) {
      const field = fields.find((f) =>
        f.toLowerCase().includes(pattern.toLowerCase())
      )
      if (field) return field
    }

    return null
  }
}

export const kepuasanMahasiswaPlugin = new KepuasanMahasiswaPlugin()
export default kepuasanMahasiswaPlugin
