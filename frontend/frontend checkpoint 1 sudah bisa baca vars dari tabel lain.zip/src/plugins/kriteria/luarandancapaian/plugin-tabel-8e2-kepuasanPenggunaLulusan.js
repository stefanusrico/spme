import { BasePlugin } from "../../core/BasePlugin.js"
import { PluginUtils } from "../../utils/PluginUtils.js"
import { fetchScoreDetails } from "../../../utils/fetchScoreDetail.js"

export class KepuasanPenggunaLulusanPlugin extends BasePlugin {
  constructor() {
    super({
      code: "8e2",
      name: "Tingkat Kepuasan Pengguna Lulusan Plugin",
      description:
        "Plugin for processing graduate user satisfaction level data",
    })
  }

  configureSection(config) {
    return {
      ...config,
      isKepuasanPenggunaSection: true,
    }
  }

  hasDefaultData() {
    return true
  }

  getJenisKemampuanOptions() {
    return [
      "Etika",
      "Keahlian pada bidang ilmu (kompetensi utama)",
      "Kemampuan berbahasa asing",
      "Penggunaan teknologi informasi",
      "Kemampuan berkomunikasi",
      "Kerjasama tim",
      "Pengembangan diri",
    ]
  }

  getDefaultData(tableCode, config = {}) {
    const now = Date.now()
    const jenisKemampuanList = this.getJenisKemampuanOptions()

    return jenisKemampuanList.map((jenis, index) => ({
      key: `default-${index + 1}-${now}-${Math.random()
        .toString(36)
        .substr(2, 5)}`,
      no: index + 1,
      selected: true,
      jenis_kemampuan: jenis,
      tingkat_sangat_baik: 0,
      tingkat_baik: 0,
      tingkat_cukup: 0,
      tingkat_kurang: 0,
      rencana_tindak_lanjut_oleh_upps_ps: "",
    }))
  }

  // ✅ Use dynamic base processing dengan konversi persentase seperti 5d
  async processExcelData(workbook, tableCode, config, prodiName, sectionCode) {
    const result = await super.processExcelData(
      workbook,
      tableCode,
      config,
      prodiName,
      sectionCode
    )

    // Konversi nilai persentase dari Excel jika ada - sama seperti 5d
    if (result && result.allRows) {
      result.allRows = result.allRows.map((item) => {
        const fieldMap = this.mapKepuasanPenggunaFields(item)

        // Konversi semua field tingkat kepuasan ke persentase
        const percentageFields = [
          fieldMap.tingkat_sangat_baik,
          fieldMap.tingkat_baik,
          fieldMap.tingkat_cukup,
          fieldMap.tingkat_kurang,
        ]

        percentageFields.forEach((field) => {
          if (field && item[field] !== undefined) {
            const rawPercentage = this.convertToPercentage(item[field])
            // ✅ Format ke 2 digit desimal menggunakan PluginUtils
            item[field] = PluginUtils.formatNumber(rawPercentage, 2)
          }
        })

        return item
      })
    }

    return result
  }

  // ✅ Helper untuk konversi ke persentase dengan 2 digit desimal - sama seperti 5d
  convertToPercentage(value) {
    if (value === null || value === undefined || value === "") {
      return 0
    }

    let result = 0

    // Jika sudah berupa number
    if (typeof value === "number") {
      // Jika nilai > 1 tapi <= 100, asumsikan sudah persentase
      if (value > 1 && value <= 100) {
        result = value
      }
      // Jika nilai <= 1, asumsikan proporsi (konversi ke persentase)
      else if (value >= 0 && value <= 1) {
        result = value * 100
      } else {
        result = value
      }
    }
    // Konversi string ke number
    else if (typeof value === "string") {
      // Hapus karakter % jika ada
      const cleanValue = value.replace(/\s*%\s*$/, "")

      const numValue = parseFloat(cleanValue)
      if (isNaN(numValue)) {
        return 0
      }

      // Jika ada simbol % di string asal, nilai sudah persentase
      if (value.includes("%")) {
        result = numValue
      }
      // Jika nilai > 1 tapi <= 100, asumsikan sudah persentase
      else if (numValue > 1 && numValue <= 100) {
        result = numValue
      }
      // Jika nilai <= 1, asumsikan proporsi (konversi ke persentase)
      else if (numValue >= 0 && numValue <= 1) {
        result = numValue * 100
      } else {
        result = numValue
      }
    }

    // ✅ Format hasil ke 2 digit desimal
    return parseFloat(PluginUtils.formatNumber(result, 2))
  }

  // ✅ Override field type detection
  detectFieldType(fieldName, value) {
    const fieldLower = fieldName.toLowerCase()

    // Percentage fields
    if (
      fieldLower.includes("tingkat_") ||
      fieldLower.includes("sangat_baik") ||
      fieldLower.includes("baik") ||
      fieldLower.includes("cukup") ||
      fieldLower.includes("kurang")
    ) {
      return "percentage"
    }

    return super.detectFieldType(fieldName, value)
  }

  // ✅ Process field value berdasarkan type - sama seperti 5d
  processFieldValue(fieldName, value, fieldType = "auto") {
    if (fieldType === "auto") {
      fieldType = this.detectFieldType(fieldName, value)
    }

    if (fieldType === "percentage") {
      const rawPercentage = this.convertToPercentage(value)
      // ✅ Format ke 2 digit desimal
      return PluginUtils.formatNumber(rawPercentage, 2)
    }

    return super.processFieldValue(fieldName, value, fieldType)
  }

  // ✅ Dynamic field mapping
  mapKepuasanPenggunaFields(sampleItem) {
    return {
      jenis_kemampuan: this.findFieldByPattern(sampleItem, [
        "jenis_kemampuan",
        "kemampuan",
        "jenis",
        "aspek",
      ]),
      tingkat_sangat_baik: this.findFieldByPattern(sampleItem, [
        "tingkat_sangat_baik",
        "sangat_baik",
        "sangat baik",
      ]),
      tingkat_baik:
        this.findFieldByPattern(sampleItem, ["tingkat_baik", "baik"]) &&
        !this.findFieldByPattern(sampleItem, ["sangat_baik"]),
      tingkat_cukup: this.findFieldByPattern(sampleItem, [
        "tingkat_cukup",
        "cukup",
      ]),
      tingkat_kurang: this.findFieldByPattern(sampleItem, [
        "tingkat_kurang",
        "kurang",
      ]),
      rencana_tindak_lanjut_oleh_upps_ps: this.findFieldByPattern(sampleItem, [
        "rencana_tindak_lanjut_oleh_upps_ps",
        "rencana_tindak_lanjut",
        "rencana",
        "tindak_lanjut",
        "upps_ps",
      ]),
    }
  }

  async calculateScore(data, config, additionalData = {}) {
    console.log("Calculating kepuasan pengguna score with data:", data)

    const allRows = Array.isArray(data) ? data : data?.allRows || []

    // Fetch data from 8e1 plugin
    const scoreDetailsResponse = await fetchScoreDetails(
      "8e1",
      additionalData.projectId
    )
    console.log("Fetched score details from 8e1:", scoreDetailsResponse)

    let NL = 0
    let NJ = 0

    if (scoreDetailsResponse) {
      NL = PluginUtils.parseNumber(scoreDetailsResponse.NL, 0)
      NJ = PluginUtils.parseNumber(scoreDetailsResponse.PR, 0) // PR from 8e1 is the number of respondents
    } else {
      NL = PluginUtils.parseNumber(additionalData.jumlahLulusan, 0)
      NJ = PluginUtils.parseNumber(additionalData.jumlahResponden, 0)
    }

    // Calculate PJ using PluginUtils.roundToDecimal with 2 digits
    const PJ = NL > 0 ? PluginUtils.roundToDecimal((NJ / NL) * 100, 2) : 0

    // Calculate Prmin using PluginUtils.roundToDecimal with 2 digits
    let Prmin
    if (NL >= 300) {
      Prmin = 30
    } else {
      Prmin = PluginUtils.roundToDecimal(50 - (NL / 300) * 20, 2)
    }

    console.log(`Using values: NL=${NL}, NJ=${NJ}, PJ=${PJ}%, Prmin=${Prmin}%`)

    const fieldMap = this.mapKepuasanPenggunaFields(allRows[0] || {})

    // ✅ Calculate TKi for each capability type - sekarang bekerja dengan persentase seperti 5d
    const tkiValues = allRows.map((item, index) => {
      // Parse nilai menjadi number untuk perhitungan
      let sangatBaik = parseFloat(item[fieldMap.tingkat_sangat_baik] || 0)
      let baik = parseFloat(item[fieldMap.tingkat_baik] || 0)
      let cukup = parseFloat(item[fieldMap.tingkat_cukup] || 0)
      let kurang = parseFloat(item[fieldMap.tingkat_kurang] || 0)

      // Konversi dari persen ke proporsi (0-1) untuk perhitungan
      let ai = sangatBaik / 100
      let bi = baik / 100
      let ci = cukup / 100
      let di = kurang / 100

      // Cek total proporsi, idealnya 1.0 (100%)
      const totalProporsi = ai + bi + ci + di

      // Normalisasi jika total tidak sama dengan 1.0
      if (totalProporsi > 0 && Math.abs(totalProporsi - 1.0) > 0.01) {
        ai = ai / totalProporsi
        bi = bi / totalProporsi
        ci = ci / totalProporsi
        di = di / totalProporsi

        console.log(
          `Normalized percentages for ${
            item[fieldMap.jenis_kemampuan]
          }: Total was ${PluginUtils.formatNumber(totalProporsi * 100, 2)}%`
        )
      }

      let TKi = 0

      if (totalProporsi > 0) {
        // Rumus TKi: (4*proporsi sangat baik + 3*proporsi baik + 2*proporsi cukup + 1*proporsi kurang) * 100
        // Ini menghasilkan TKi dalam bentuk persentase dari skala 1-4
        TKi = (4 * ai + 3 * bi + 2 * ci + 1 * di) * 100
        TKi = parseFloat(PluginUtils.formatNumber(TKi, 2))
      }

      console.log(
        `TKi ${index + 1} (${item[fieldMap.jenis_kemampuan]}): (4×${ai.toFixed(
          3
        )} + 3×${bi.toFixed(3)} + 2×${ci.toFixed(3)} + 1×${di.toFixed(
          3
        )}) × 100 = ${TKi}`
      )

      return TKi
    })

    console.log("TKI values (percentage weighted scores):", tkiValues)

    // Calculate sum of all TKi values
    const totalTKi = tkiValues.reduce((sum, tki) => sum + tki, 0)

    // Calculate average TKi and convert to 4-point scale by dividing by 100
    const avgTKi =
      tkiValues.length > 0
        ? PluginUtils.roundToDecimal(totalTKi / (tkiValues.length * 100), 2)
        : 0

    console.log(
      `Total TKi: ${totalTKi}, Average TKi (on 4-point scale): ${avgTKi}`
    )

    // Apply adjustment if response percentage doesn't meet minimum requirement
    let finalScore = avgTKi
    if (PJ < Prmin) {
      finalScore = PluginUtils.roundToDecimal((PJ / Prmin) * avgTKi, 2)
      console.log(
        `Adjusted score due to low response rate: (${PJ}/${Prmin}) × ${avgTKi} = ${finalScore}`
      )
    }

    // Ensure score is between 0 and 4
    finalScore = PluginUtils.roundToDecimal(
      Math.max(0, Math.min(4, finalScore)),
      2
    )

    console.log("Score Detail:", {
      NL,
      NJ,
      PJ,
      Prmin,
      totalTKi,
      avgTKi,
      finalScore,
    })

    return {
      scores: [{ butir: 68, nilai: finalScore }],
      scoreDetail: {
        NL,
        NJ,
        PJ: PJ + "%",
        Prmin: Prmin + "%",
        totalTKi: PluginUtils.formatNumber(totalTKi, 2),
        avgTKi: avgTKi,
      },
    }
  }

  // ✅ Dynamic normalization - sekarang menangani persentase dan memformatnya seperti 5d
  normalizeData(data, config = {}) {
    if (!Array.isArray(data)) return []

    return data
      .filter((item) => {
        const fieldMap = this.mapKepuasanPenggunaFields(item)
        if (!item[fieldMap.jenis_kemampuan]) return true
        const normalized = String(item[fieldMap.jenis_kemampuan])
          .toLowerCase()
          .trim()
        return !["jumlah", "total", "sum", "rata-rata", "average"].includes(
          normalized
        )
      })
      .map((item, index) => {
        const result = {
          ...item,
          id: item.id || `row-${Math.random().toString(36).substring(2, 9)}`,
          key: item.key || `row-${Math.random().toString(36).substring(2, 9)}`,
          no: index + 1,
        }

        const fieldMap = this.mapKepuasanPenggunaFields(result)

        // ✅ Process semua field berdasarkan mapping
        Object.entries(fieldMap).forEach(([key, fieldName]) => {
          if (fieldName && result[fieldName] !== undefined) {
            const fieldType = this.detectFieldType(fieldName, result[fieldName])
            result[fieldName] = this.processFieldValue(
              fieldName,
              result[fieldName],
              fieldType
            )
          }
        })

        return result
      })
  }

  // ✅ Dynamic validation - update untuk memvalidasi persentase seperti 5d
  validateData(data) {
    const errors = []
    const requiredCapabilities = this.getJenisKemampuanOptions()

    if (!Array.isArray(data)) {
      errors.push("Data utama harus berupa array.")
      return { valid: false, errors }
    }

    const fieldMap = this.mapKepuasanPenggunaFields(data[0] || {})

    // Check if all required capabilities are present
    const existingCapabilities = data.map((item) =>
      String(item[fieldMap.jenis_kemampuan] || "")
        .toLowerCase()
        .trim()
    )

    requiredCapabilities.forEach((capability) => {
      const found = existingCapabilities.some(
        (existing) =>
          existing.includes(capability.toLowerCase()) ||
          capability.toLowerCase().includes(existing)
      )

      if (!found) {
        errors.push(`Jenis kemampuan "${capability}" wajib diisi`)
      }
    })

    // Validate each row
    data.forEach((item, index) => {
      if (
        fieldMap.jenis_kemampuan &&
        (!item[fieldMap.jenis_kemampuan] ||
          String(item[fieldMap.jenis_kemampuan]).trim() === "")
      ) {
        errors.push(`Baris ${index + 1}: Jenis kemampuan harus diisi`)
      }

      // ✅ Validasi field persentase - sama seperti 5d
      const percentageFields = [
        { field: fieldMap.tingkat_sangat_baik, name: "Tingkat Sangat Baik" },
        { field: fieldMap.tingkat_baik, name: "Tingkat Baik" },
        { field: fieldMap.tingkat_cukup, name: "Tingkat Cukup" },
        { field: fieldMap.tingkat_kurang, name: "Tingkat Kurang" },
      ].filter((x) => x.field)

      percentageFields.forEach(({ field, name }) => {
        const val = parseFloat(item[field] || 0)
        if (val < 0 || val > 100) {
          errors.push(
            `Baris ${
              index + 1
            }: '${name}' harus berupa persentase antara 0-100%. Ditemukan: ${val}%`
          )
        }
      })

      // Validasi total persentase mendekati 100%
      const totalPersen = percentageFields.reduce((sum, { field }) => {
        return sum + parseFloat(item[field] || 0)
      }, 0)

      if (totalPersen > 0 && Math.abs(totalPersen - 100) > 5) {
        errors.push(
          `Baris ${
            index + 1
          }: Total persentase tingkat kepuasan seharusnya 100%. Ditemukan: ${PluginUtils.formatNumber(
            totalPersen,
            2
          )}%`
        )
      }
    })

    return {
      valid: errors.length === 0,
      errors,
    }
  }

  // ✅ Helper method
  findFieldByPattern(item, patterns) {
    const fields = Object.keys(item)

    for (const pattern of patterns) {
      const field = fields.find((f) =>
        f.toLowerCase().includes(pattern.toLowerCase())
      )
      if (field) return field
    }

    return null
  }
}

export const kepuasanPenggunaLulusanPlugin = new KepuasanPenggunaLulusanPlugin()
export default kepuasanPenggunaLulusanPlugin
