import { BasePlugin } from "../../core/BasePlugin.js"
import { PluginUtils } from "../../utils/PluginUtils.js"
import { processExcelDataBase } from "../../../utils/tableUtils"
import { fetchScoreDetails } from "../../../utils/fetchScoreDetail.js"

export class DosenTetapPlugin extends BasePlugin {
  constructor() {
    super({
      code: "3a1",
      name: "Dosen Tetap Perguruan Tinggi",
      description: "Plugin for processing permanent university lecturer data",
    })
  }

  configureSection(config) {
    return { ...config, isDosenTetapSection: true }
  }

  // ✅ Use dynamic base processing
  async processExcelData(workbook, tableCode, config, prodiName, sectionCode) {
    return super.processExcelData(
      workbook,
      tableCode,
      config,
      prodiName,
      sectionCode
    )
  }

  async calculateScore(data, config, additionalData = {}) {
    const metrics = await this.calculateMetrics(data, additionalData)
    const scores = this.calculateDetailedScores(metrics)

    return {
      scores: scores.map((s) => ({ butir: s.butir, nilai: s.nilai })),
      scoreDetail: this.formatScoreDetail(metrics),
    }
  }

  async calculateMetrics(data, additionalData) {
    const { projectId } = additionalData
    let NM = 0
    let NDTT = 0

    if (projectId) {
      try {
        const scoreDetail2a1 = await fetchScoreDetails("2a1", projectId)
        const scoreDetail3a4 = await fetchScoreDetails("3a4", projectId)
        NM = scoreDetail2a1?.NM || 0
        NDTT = scoreDetail3a4?.NDTT || 0
      } catch (error) {
        console.warn("Failed to fetch NDTT:", error)
      }
    }

    // ✅ Dynamic field mapping for calculations
    const fieldMap = this.mapDosenFields(data[0] || {})

    // Basic counts using dynamic field access
    const NDT = this.countDosenByCriteria(data, {
      [fieldMap.nidn]: (val) => val?.trim(),
    })

    const NDTPS = this.countDosenByCriteria(data, {
      [fieldMap.nidn]: (val) => val?.trim(),
      [fieldMap.kesesuaian]: (val) => this.hasKesesuaian(val),
    })

    const NDS3 = this.countDosenByCriteria(data, {
      [fieldMap.nama]: (val) => val?.trim(),
      [fieldMap.pendidikan]: (val) => val?.trim(),
      [fieldMap.kesesuaian]: (val) => this.hasKesesuaian(val),
    })

    const NDSK = this.countDosenByCriteria(data, {
      [fieldMap.nama]: (val) => val?.trim(),
      [fieldMap.sertifikasi]: (val) => val?.trim(),
      [fieldMap.lembaga]: (val) => val?.trim(),
    })

    // Jabatan counts using dynamic fields
    const NDGB = this.countByJabatan(data, fieldMap.jabatan, [
      "guru besar",
      "profesor",
      "professor",
    ])
    const NDLK = this.countByJabatan(data, fieldMap.jabatan, ["lektor kepala"])
    const NDL = this.countByJabatan(
      data,
      fieldMap.jabatan,
      ["lektor"],
      ["lektor kepala"]
    )

    const metrics = {
      NDT,
      NDTPS,
      NDS3,
      NDSK,
      NDGB,
      NDLK,
      NDL,
      NDTT,
      NM,
    }

    metrics.PDS3 = NDTPS > 0 ? (NDS3 / NDTPS) * 100 : 0
    metrics.PDSK = NDTPS > 0 ? (NDSK / NDTPS) * 100 : 0
    metrics.PGBLKL = NDTPS > 0 ? ((NDGB + NDLK + NDL) / NDTPS) * 100 : 0
    metrics.PDTT = NDT + NDTT > 0 ? (NDTT / (NDT + NDTT)) * 100 : 0
    metrics.RMD = NDTPS > 0 ? NM / NDTPS : 0

    return metrics
  }

  // ✅ NEW: Map dynamic fields to standard field types
  mapDosenFields(sampleItem) {
    const fields = Object.keys(sampleItem)

    return {
      nidn:
        this.findFieldByPattern(sampleItem, ["nidn", "nidk", "nip"]) ||
        "nidn_nidk",
      nama:
        this.findFieldByPattern(sampleItem, ["nama_dosen", "nama"]) ||
        "nama_dosen",
      kesesuaian:
        this.findFieldByPattern(sampleItem, ["kesesuaian", "kompetensi"]) ||
        "kesesuaian_dengan_kompetensi_inti_ps_3",
      pendidikan:
        this.findFieldByPattern(sampleItem, [
          "doktor",
          "pendidikan",
          "gelar",
        ]) || "doktor_doktor_terapan_nama_prodi_pasca_sarjana_1",
      sertifikasi:
        this.findFieldByPattern(sampleItem, [
          "sertifikasi",
          "sertifikat",
          "kompetensi",
        ]) || "bidang_sertifikasi_sertifikat_kompetensi_profesi_industri_5",
      lembaga:
        this.findFieldByPattern(sampleItem, ["lembaga", "penerbit"]) ||
        "lembaga_penerbit_sertifikat_kompetensi_profesi_industri_5",
      jabatan:
        this.findFieldByPattern(sampleItem, ["jabatan", "akademik"]) ||
        "jabatan_akademik",
    }
  }

  // ✅ Helper methods using dynamic fields
  findFieldByPattern(item, patterns) {
    const fields = Object.keys(item)

    for (const pattern of patterns) {
      const field = fields.find((f) =>
        f.toLowerCase().includes(pattern.toLowerCase())
      )
      if (field) return field
    }

    return null
  }

  countDosenByCriteria(data, criteria) {
    return data.filter((dosen) => {
      return Object.entries(criteria).every(([field, expectedValue]) => {
        if (!field || !dosen.hasOwnProperty(field)) return false

        const actualValue = dosen[field]

        if (typeof expectedValue === "function") {
          return expectedValue(actualValue)
        }

        if (Array.isArray(expectedValue)) {
          return expectedValue.includes(actualValue)
        }

        return actualValue === expectedValue
      })
    }).length
  }

  countByJabatan(data, jabatanField, includes = [], excludes = []) {
    if (!jabatanField) return 0

    return this.countDosenByCriteria(data, {
      [this.mapDosenFields(data[0] || {}).nidn]: (val) => val?.trim(),
      [this.mapDosenFields(data[0] || {}).kesesuaian]: (val) =>
        this.hasKesesuaian(val),
      [jabatanField]: (val) => {
        if (!val) return false
        const jabatanLower = val.toLowerCase()

        if (excludes.some((exc) => jabatanLower.includes(exc))) {
          return false
        }

        return includes.some((inc) => jabatanLower.includes(inc))
      },
    })
  }

  hasKesesuaian(value) {
    return ["V", "v", "√", "✓", "Ya", "ya", "1", 1, true].includes(
      String(value).trim()
    )
  }

  calculateDetailedScores(metrics) {
    // Implement scoring logic using metrics
    return [
      {
        butir: 16,
        nilai: parseFloat(
          PluginUtils.formatNumber(this.calculateKecukupanScore(metrics), 2)
        ),
      },
      {
        butir: 17,
        nilai: parseFloat(
          PluginUtils.formatNumber(this.calculateKualifikasiScore(metrics), 2)
        ),
      },
      {
        butir: 18,
        nilai: parseFloat(
          PluginUtils.formatNumber(this.calculateSertifikasiScore(metrics), 2)
        ),
      },
      {
        butir: 19,
        nilai: parseFloat(
          PluginUtils.formatNumber(this.calculateJabatanScore(metrics), 2)
        ),
      },
      {
        butir: 20,
        nilai: parseFloat(
          PluginUtils.formatNumber(this.calculateRasioScore(metrics), 2)
        ),
      },
    ]
  }

  // ✅ Implement scoring methods
  calculateKecukupanScore(metrics) {
    // Implement scoring logic
    return metrics.RMD >= 20 ? 4 : (metrics.RMD / 20) * 4
  }

  calculateKualifikasiScore(metrics) {
    return metrics.PDS3 >= 70 ? 4 : (metrics.PDS3 / 70) * 4
  }

  calculateSertifikasiScore(metrics) {
    return metrics.PDSK >= 70 ? 4 : (metrics.PDSK / 70) * 4
  }

  calculateJabatanScore(metrics) {
    return metrics.PGBLKL >= 70 ? 4 : (metrics.PGBLKL / 70) * 4
  }

  calculateRasioScore(metrics) {
    return metrics.PDTT <= 10 ? 4 : Math.max(0, 4 - (metrics.PDTT - 10) / 10)
  }

  formatScoreDetail(metrics) {
    return {
      ...metrics,
      PDS3: `${parseFloat(PluginUtils.formatNumber(metrics.PDS3, 2))}%`,
      PDSK: `${parseFloat(PluginUtils.formatNumber(metrics.PDSK, 2))}%`,
      PGBLKL: `${parseFloat(PluginUtils.formatNumber(metrics.PGBLKL, 2))}%`,
      PDTT: `${parseFloat(PluginUtils.formatNumber(metrics.PDTT, 2))}%`,
      RMD: parseFloat(PluginUtils.formatNumber(metrics.RMD, 2)),
    }
  }

  // ✅ Dynamic validation
  validateData(data) {
    const errors = []
    const fieldMap = this.mapDosenFields(data[0] || {})

    data.forEach((item, index) => {
      if (!item[fieldMap.nama]) {
        errors.push(`Row ${index + 1}: Nama dosen harus diisi`)
      }

      if (!item[fieldMap.nidn]) {
        errors.push(`Row ${index + 1}: NIDN/NIDK harus diisi`)
      } else if (!/^\d+$/.test(String(item[fieldMap.nidn]).trim())) {
        errors.push(`Row ${index + 1}: NIDN/NIDK harus berupa angka`)
      }
    })

    return {
      valid: errors.length === 0,
      errors,
    }
  }
}

export default new DosenTetapPlugin()
